package tema2;

/**
 * Created by dragos on 12.03.2017.
 */
public class Problema1 {

    public static void main(String[] args){

        double[] v = new double[]{5, 3, 6, 4, 8, 6};

        if(v.length == v[0]){
            System.out.println("formeaza multime");
        } else {
            System.out.println("nu formeaza multime");
        }
    }
}
